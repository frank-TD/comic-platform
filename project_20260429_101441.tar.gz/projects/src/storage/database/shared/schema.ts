import { pgTable, serial, timestamp, text, varchar, index } from "drizzle-orm/pg-core"
import { sql } from "drizzle-orm"

export const healthCheck = pgTable("health_check", {
	id: serial().notNull(),
	updatedAt: timestamp("updated_at", { withTimezone: true, mode: 'string' }).defaultNow(),
});

export const chatMessages = pgTable(
  "chat_messages",
  {
    id: serial().primaryKey(),
    session_id: varchar("session_id", { length: 64 }),
    role: varchar("role", { length: 16 }).notNull(),
    content: text("content").notNull(),
    created_at: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => [
    index("chat_messages_session_id_idx").on(table.session_id),
    index("chat_messages_created_at_idx").on(table.created_at),
  ]
);
