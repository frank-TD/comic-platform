const express = require('express');
const cors = require('cors');
const path = require('path');
const https = require('https');

// Supabase 配置
let supabaseClient = null;

async function initSupabase() {
    try {
        // 尝试通过 coze-coding-dev-sdk 加载环境变量
        const sdk = require('coze-coding-dev-sdk');
        if (sdk.loadEnv) {
            sdk.loadEnv();
        }
    } catch (e) {
        // SDK 不可用
    }

    const SUPABASE_URL = process.env.COZE_SUPABASE_URL || '';
    const SUPABASE_ANON_KEY = process.env.COZE_SUPABASE_ANON_KEY || '';

    if (!SUPABASE_URL || !SUPABASE_ANON_KEY) {
        console.warn('Supabase 未配置，聊天记录将不会持久化');
        return;
    }

    try {
        const { createClient } = require('@supabase/supabase-js');
        supabaseClient = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
        console.log('Supabase 已连接');
    } catch (e) {
        console.warn('Supabase 初始化失败:', e.message);
    }
}

const app = express();
const PORT = 5000;

// Coze 智能体配置
const API_URL = process.env.API_URL || 'https://mmyr73d5p8.coze.site/stream_run';
const PROJECT_ID = process.env.PROJECT_ID || '7632246267833434147';

// 沙箱环境备用 Token（生产环境请通过环境变量配置）
const SANDBOX_API_TOKEN = 'pat_FrqNvWRLjaot6TGSVspzzOrBsFKFmakMrW4VoJUmHEDINskNDXezPLvqUQ36DjbB';
const API_TOKEN = process.env.API_TOKEN || SANDBOX_API_TOKEN;

console.log('API_TOKEN 来源:', process.env.API_TOKEN ? '环境变量' : '沙箱备用');

// 中间件
app.use(cors());
app.use(express.json());

// 静态文件服务
app.use(express.static(path.join(__dirname)));

// 健康检查接口
app.get('/health', (req, res) => {
    res.json({ status: 'healthy', message: '服务运行正常' });
});

// 查询历史记录（3天内）
app.get('/api/history', async (req, res) => {
    if (!supabaseClient) {
        return res.json({ success: true, data: [], message: '数据库未配置' });
    }

    try {
        const threeDaysAgo = new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString();

        const { data, error } = await supabaseClient
            .from('chat_messages')
            .select('id, role, content, created_at')
            .gte('created_at', threeDaysAgo)
            .order('created_at', { ascending: true })
            .limit(1000);

        if (error) throw new Error(`查询历史记录失败: ${error.message}`);

        res.json({ success: true, data: data || [] });
    } catch (error) {
        console.error('查询历史记录错误:', error.message);
        res.json({ success: true, data: [], message: error.message });
    }
});

// 保存单条消息到数据库
async function saveMessage(role, content) {
    if (!supabaseClient) return;

    try {
        const { error } = await supabaseClient
            .from('chat_messages')
            .insert({ role, content });

        if (error) {
            console.error('保存消息失败:', error.message);
        }
    } catch (e) {
        console.error('保存消息异常:', e.message);
    }
}

// 清理3天前的记录
async function cleanupOldMessages() {
    if (!supabaseClient) return;

    try {
        const threeDaysAgo = new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString();

        const { error } = await supabaseClient
            .from('chat_messages')
            .delete()
            .lt('created_at', threeDaysAgo);

        if (error) {
            console.error('清理旧消息失败:', error.message);
        } else {
            console.log('已清理3天前的聊天记录');
        }
    } catch (e) {
        console.error('清理旧消息异常:', e.message);
    }
}

// 智能对话接口（流式响应）
app.post('/api/chat', async (req, res) => {
    const { message, session_id } = req.body;

    if (!message) {
        return res.status(400).json({ error: '消息不能为空' });
    }

    // 保存用户消息到数据库
    await saveMessage('user', message);

    try {
        // 准备请求 Coze Agent
        const cozeBody = JSON.stringify({
            content: {
                query: {
                    prompt: [{
                        type: 'text',
                        content: { text: message }
                    }]
                }
            },
            type: 'query',
            session_id: session_id || 'default',
            project_id: parseInt(PROJECT_ID)
        });

        // 解析 URL
        const url = new URL(API_URL);

        // 创建请求选项
        const options = {
            hostname: url.hostname,
            port: url.port || 443,
            path: url.pathname + url.search,
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${API_TOKEN}`,
                'Content-Type': 'application/json',
                'Accept': 'text/event-stream'
            }
        };

        // 设置 SSE 响应头
        res.setHeader('Content-Type', 'text/event-stream');
        res.setHeader('Cache-Control', 'no-cache');
        res.setHeader('Connection', 'keep-alive');
        res.setHeader('Transfer-Encoding', 'chunked');

        // 标记是否已发送内容（用于保存助手回复）
        let assistantContent = '';
        let hasContent = false;

        // 发送 Coze 请求
        const cozeReq = https.request(options, (cozeRes) => {
            let buffer = '';

            cozeRes.on('data', (chunk) => {
                buffer += chunk.toString();
                const lines = buffer.split('\n');
                buffer = lines.pop() || '';

                for (const line of lines) {
                    const trimmed = line.trim();
                    if (!trimmed) continue;

                    if (trimmed.startsWith('data:')) {
                        const dataStr = trimmed.slice(5).trim();
                        if (dataStr === '[DONE]') {
                            res.write('data: [DONE]\n\n');
                            // 保存助手回复到数据库
                            if (assistantContent) {
                                saveMessage('assistant', assistantContent);
                            }
                            res.end();
                            return;
                        }

                        try {
                            const data = JSON.parse(dataStr);
                            const answer = data.content?.answer;
                            if (answer && typeof answer === 'string') {
                                hasContent = true;
                                assistantContent += answer;
                                res.write(`data: ${JSON.stringify({ text: answer })}\n\n`);
                            }
                        } catch (e) {
                            // 忽略无法解析的数据
                        }
                    }
                }
            });

            cozeRes.on('end', () => {
                if (!hasContent) {
                    res.write(`data: ${JSON.stringify({ error: '智能体未返回有效内容' })}\n\n`);
                }
                // 保存助手回复到数据库
                if (assistantContent) {
                    saveMessage('assistant', assistantContent);
                }
                res.write('data: [DONE]\n\n');
                res.end();
            });

            cozeRes.on('error', (error) => {
                console.error('Coze 响应错误:', error.message);
                res.write(`data: ${JSON.stringify({ error: '智能体连接错误: ' + error.message })}\n\n`);
                res.write('data: [DONE]\n\n');
                res.end();
            });
        });

        cozeReq.on('error', (error) => {
            console.error('Coze 请求错误:', error.message);
            res.write(`data: ${JSON.stringify({ error: '智能体请求失败: ' + error.message })}\n\n`);
            res.write('data: [DONE]\n\n');
            res.end();
        });

        cozeReq.write(cozeBody);
        cozeReq.end();

    } catch (error) {
        console.error('对话接口错误:', error.message);
        res.write(`data: ${JSON.stringify({ error: '对话失败: ' + error.message })}\n\n`);
        res.write('data: [DONE]\n\n');
        res.end();
    }
});

// 初始化 Supabase 并启动服务器
initSupabase().then(() => {
    app.listen(PORT, () => {
        console.log(`服务器运行在 http://localhost:${PORT}`);
        console.log(`API_TOKEN 状态: ${API_TOKEN ? '已配置' : '未配置'}`);
        console.log(`Supabase 状态: ${supabaseClient ? '已连接' : '未连接'}`);

        // 启动时清理一次旧记录
        cleanupOldMessages();

        // 每6小时清理一次旧记录
        setInterval(cleanupOldMessages, 6 * 60 * 60 * 1000);
    });
});
